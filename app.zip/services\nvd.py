"""
NVD CVE lookup service.
Reused/adapted from the original port-scanner project's CVE lookup logic,
now applied to (software name + version) instead of (port -> service name).
"""

import logging
import requests

logger = logging.getLogger("device-tracker")

NVD_BASE_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"

# Simple severity ranking so we can sort/prioritize results later.
SEVERITY_ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "UNKNOWN": 0}


def lookup_cves(keyword: str, api_key: str | None, limit: int = 5):
    """Query NVD for CVEs matching a keyword (e.g. 'Windows Server 2016',
    'OpenSSL 1.0.1'). Returns a list of dicts with id, description, severity."""
    if not api_key:
        return [{"error": "NVD API key not configured"}]

    headers = {"apiKey": api_key}
    params = {"keywordSearch": keyword, "resultsPerPage": limit}

    try:
        resp = requests.get(NVD_BASE_URL, headers=headers, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as e:
        logger.warning("NVD lookup failed for '%s': %s", keyword, e)
        return [{"error": f"CVE lookup temporarily unavailable for {keyword}"}]

    results = []
    for item in data.get("vulnerabilities", []):
        cve = item["cve"]
        severity = "UNKNOWN"
        try:
            metrics = cve.get("metrics", {})
            for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
                if key in metrics:
                    severity = metrics[key][0]["cvssData"].get(
                        "baseSeverity", "UNKNOWN"
                    ).upper()
                    break
        except (KeyError, IndexError):
            pass

        results.append({
            "id": cve["id"],
            "description": cve["descriptions"][0]["value"][:250],
            "severity": severity,
        })

    results.sort(key=lambda r: SEVERITY_ORDER.get(r["severity"], 0), reverse=True)
    return results


def scan_device(device: dict, api_key: str | None):
    """Run CVE lookups for a device's OS and each piece of software.
    Returns the device dict enriched with a 'findings' list and a
    computed overall risk level."""
    findings = []

    os_keyword = f"{device['os']} {device['os_version']}"
    findings.append({"component": os_keyword, "cves": lookup_cves(os_keyword, api_key)})

    for sw in device["software"]:
        findings.append({"component": sw, "cves": lookup_cves(sw, api_key)})

    # Compute overall risk = highest severity found across all components
    highest = 0
    for f in findings:
        for cve in f["cves"]:
            sev = cve.get("severity", "UNKNOWN")
            highest = max(highest, SEVERITY_ORDER.get(sev, 0))

    risk_level = {4: "critical", 3: "high", 2: "medium", 1: "low", 0: "unknown"}[highest]

    return {**device, "findings": findings, "risk_level": risk_level}
